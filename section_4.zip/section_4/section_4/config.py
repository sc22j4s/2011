WTF_CSRF_ENABLED = True

# You should change this
SECRET_KEY = 'a-very-secret-secret'
